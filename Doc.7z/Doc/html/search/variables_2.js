var searchData=
[
  ['name_44',['name',['../structitem__t.html#a5ac083a645d964373f022d03df4849c8',1,'item_t']]]
];
