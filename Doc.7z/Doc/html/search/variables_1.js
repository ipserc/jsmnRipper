var searchData=
[
  ['jtype_43',['jtype',['../structitem__t.html#af9ce7ed594c06a8c02d6455ab676a6a8',1,'item_t']]]
];
