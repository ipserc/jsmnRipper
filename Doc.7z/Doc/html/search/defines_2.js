var searchData=
[
  ['version_47',['VERSION',['../jsmn_ripper_8h.html#a1c6d5de492ac61ad29aec7aa9a436bbf',1,'jsmnRipper.h']]]
];
